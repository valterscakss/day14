
import org.apache.log4j.{Level, Logger}
import org.apache.spark.rdd.RDD
import org.apache.spark.streaming._
import org.apache.spark.{SparkConf, SparkContext}



object day4 {
 // println("Object Day4")
 // println("------")

  def main(args: Array[String]){
    val conf = new SparkConf().setAppName("Day4").setMaster("local[2]")
    val ssc = new StreamingContext(conf, Seconds(4))
val requests = ssc.socketTextStream("localhost", 33001)
    val columns = requests.map(_.split(" "))
    //columns.print()
    //val result = columns.filter(col
   val toString = columns.map(_.mkString("[", ", ", ""))
    val result = toString.map(a => a.split(", ")(2).split("/")(2)).map(string => (string,1)).reduceByKey(_+_)
  // val test = toString)
//val pp = test.map(_.mkString("[", ", ", "]"))


 //  val split = toString.map(a=>a.split(", "))
  result.print()
    val next = columns.map(b => (b(0),b(1))).transform(rdd => rdd.distinct)map{case (a,b) => (b,1)}
      val next1 = next.reduceByKey(_+_)
    val results_2 = next1.filter(t => t._2 >1)
    results_2.print()


results_2.print()
   // val rdd = ssc.socketTextStream("localhost", 3301)
    ssc.start()
    ssc.awaitTermination()
//println("We did it to last stage in main()")


    /*
    val codes = rdd.map(_.split("\t").head)
    val initialSet = Set.empty[Int]
    val addToSet = {(s: Set[Int], v:Int) => s + v}
    val mergeSets = {(s1: Set[Int], s2: Set[Int]) => s1 ++ s2}
    ssc.start()
    ssc.awaitTermination()
*/
   // val distinctValSets = rdd.aggregateByKey(initialSet)(addToSet, mergeSets)
//    val distinctValCountd = rdd.map({case(k,s) => (k,s.size)})



 }






  }


